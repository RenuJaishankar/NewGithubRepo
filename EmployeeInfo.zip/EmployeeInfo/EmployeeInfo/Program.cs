﻿using System;

namespace EmployeeInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Lucinda Potter");
            Console.WriteLine("6/24/1992");
            Console.WriteLine("work :312 - 982 - 1010");
            Console.WriteLine("email:ewoz@woz - u.com");

        }
    }
}
